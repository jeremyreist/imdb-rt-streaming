/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
function requestHostPermissions(hosts) {
    return new Promise(function (resolve, reject) {
        chrome.permissions.request({
            origins: hosts
        }, function (granted) {
            if (granted) {
                resolve();
            }
            else {
                reject();
            }
        });
    });
}
function checkAndRequestPermissions() {
    var permissions = {
        origins: [
            "https://www.netflix.com/*",
            "https://www.disneyplus.com/*",
            "https://play.hbomax.com/*",
            "https://www.primevideo.com/*",
            "https://www.apple.com/*",
            "https://www.hulu.com/*"
        ]
    };
    chrome.permissions.contains(permissions, function (result) {
        if (result) {
            // The extension has the permissions.
            console.log('Permissions already granted');
        }
        else {
            // The extension doesn't have the permissions. Request them.
            requestHostPermissions(permissions.origins)
                .then(function () { return console.log('Permissions granted'); })
                .catch(function () { return console.log('Permissions denied'); });
        }
    });
}
chrome.runtime.onInstalled.addListener(checkAndRequestPermissions);
chrome.runtime.onStartup.addListener(checkAndRequestPermissions);

/******/ })()
;
//# sourceMappingURL=background.js.map